`timescale 1ns / 1ps

module Convolution_test_1_tb;

    // Parameters
    parameter MATRIX_ROWS = 2;
    parameter MATRIX_COLS = 200;
    parameter FILTER_ROWS = 2;
    parameter FILTER_COLS = 8;
    parameter RESULT_ROWS = 2;
    parameter RESULT_COLS = 193;

    // Derived parameters
    parameter MATRIX_SIZE = MATRIX_ROWS * MATRIX_COLS * 16;  // 6400 bits
    parameter FILTER_SIZE = FILTER_ROWS * FILTER_COLS * 16;  // 256 bits
    parameter RESULT_SIZE = RESULT_ROWS * RESULT_COLS * 16;  // 6176 bits

    // Inputs
    reg clk;
    reg signed [MATRIX_SIZE-1:0] matrix;
    reg signed [FILTER_SIZE-1:0] filter;

    // Outputs
    wire signed [RESULT_SIZE-1:0] result;




    // Instantiate the DUT
    // MAKE CHSNGE HERE
    Convolution_test_1 Convolution_test_1 (
        .matrix(matrix),
        .filter(filter),
        .result(result),
        .clk(clk)
    );




    // Clock generation
    always #5 clk = ~clk;

    // Memory for loading inputs
    reg signed [15:0] matrix_memory [0:MATRIX_ROWS * MATRIX_COLS - 1];
    reg signed [15:0] filter_memory [0:FILTER_ROWS * FILTER_COLS - 1];

    integer i, filter_index;
    reg [100*8:1] filter_filename; // Sufficient size for file names

    // Testbench logic
    initial begin
        // Initialize inputs
        clk = 0;
        matrix = 0;
        filter = 0;

        // Load the matrix from .mif file
        $readmemb("binary_16bit.mif", matrix_memory);

        // Ensure the matrix memory size is correct (400 entries)
        if (MATRIX_ROWS * MATRIX_COLS != 400) begin
            $display("Error: matrix memory size mismatch. Expected 400 entries.");
            $stop;
        end

        // Flatten the matrix memory into the `matrix` input
        for (i = 0; i < MATRIX_ROWS * MATRIX_COLS; i = i + 1) begin
            matrix[i*16 +: 16] = matrix_memory[i];
//            Display each matrix entry for debugging
//            $display("Matrix[%0d]: %d", i, $signed(matrix_memory[i]));
        end

        // Loop through filters dynamically
        for (filter_index = 0; filter_index < 64; filter_index = filter_index + 1) begin
            // Generate filter file name
            $sformat(filter_filename, "f_64_%0d.mif", filter_index);
            
            // Load the filter from the generated file
            $readmemb(filter_filename, filter_memory);

            // Flatten the filter memory into the `filter` input
            for (i = 0; i < FILTER_ROWS * FILTER_COLS; i = i + 1) begin
                filter[i*16 +: 16] = filter_memory[i];
                // Display each matrix entry for debugging
//                $display("filter_memory[%0d]: %d", i, $signed(filter_memory[i]));
            end

            // Wait for computation to complete
            #100;
//for (i = 0; i < RESULT_ROWS * RESULT_COLS; i = i + 1) begin
            // Display the result matrix for the current filter
            $display("Result Matrix for Filter %0d (2x193):", filter_index);
            for (i = 0; i < 1 * 2; i = i + 1) begin
                $display("Row %0d, Column %0d: %0d", i / RESULT_COLS, i % RESULT_COLS, $signed(result[i*16 +: 16]));
            end
        end

        // Finish simulation
        $stop;
    end

endmodule
