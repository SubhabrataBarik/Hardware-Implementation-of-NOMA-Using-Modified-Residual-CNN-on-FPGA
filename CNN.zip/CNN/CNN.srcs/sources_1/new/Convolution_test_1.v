`timescale 1ns / 1ps

module Convolution_test_1(
    input signed [6399:0] matrix,     // Flattened matrix, 400 entries of 16 bits each
    input signed [255:0] filter,      // Flattened filter, 16 entries of 16 bits each
    output reg signed [6175:0] result, // 386 output values, 16 bits per entry
    input clk
);

    integer i, j;                 // Loop variables
    reg signed [31:0] product;    // Temporary variable for storing signed product
    reg signed [15:0] partial_sum; // Accumulated result, 16 bits wide


    always @(posedge clk) begin
        for (i = 0; i < 193; i = i + 1) begin  // Limit to 193 iterations
            partial_sum = 16'sh0000; // Reset partial sum to 0 in hexadecimal (signed)

            // Convolution for the first half of the filter
            for (j = 0; j < 8; j = j + 1) begin
                if (((i + j + 1) * 16 - 1) < 3200) begin
                    // Perform multiplication in hexadecimal
                    product = $signed(matrix[(i + j + 1) * 16 - 1 -: 16]) * $signed(filter[(j + 1) * 16 - 1 -: 16]);
                    partial_sum = partial_sum + product[15:0]; // Accumulate the lower 16 bits of the product

                    // Display debugging information
//                    $display("First Half - Matrix[%0d]: %d, Filter[%0d]: %d, Product: %d, Partial Sum: %d",
//                        (i + j + 1),
//                        $signed(matrix[(i + j + 1) * 16 - 1 -: 16]),
//                        (j + 1),
//                        $signed(filter[(j + 1) * 16 - 1 -: 16]),
//                        $signed(product[15:0]),
//                        $signed(partial_sum));
                end
            end

            // Convolution for the second half of the filter
            for (j = 0; j < 8; j = j + 1) begin
                if (((i + j + 200 + 1) * 16 - 1) < 6400) begin
                    // Perform multiplication in hexadecimal
                    product = $signed(matrix[(i + j + 200 + 1) * 16 - 1 -: 16]) * $signed(filter[(j + 8 + 1) * 16 - 1 -: 16]);
                    partial_sum = partial_sum + product[15:0];

                    // Display debugging information
//                    $display("Second Half - Matrix[%0d]: %d, Filter[%0d]: %d, Product: %d, Partial Sum: %d",
//                        (i + j + 200 + 1),
//                        $signed(matrix[(i + j + 200 + 1) * 16 - 1 -: 16]),
//                        (j + 8 + 1),
//                        $signed(filter[(j + 8 + 1) * 16 - 1 -: 16]),
//                        $signed(product[15:0]),
//                        $signed(partial_sum));
                end
            end

            // Store the result in the appropriate slice (in hexadecimal format)
            result[(i + 1) * 16 - 1 -: 16] = partial_sum;
            result[(i + 193 + 1) * 16 - 1 -: 16] = partial_sum;

            // Display the final result for this index
//            $display("Result[%0d]: %d", i, $signed(result[(i + 1) * 16 - 1 -: 16]));
        end
    end

endmodule
