`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 21.10.2024 20:53:24
// Design Name: 
// Module Name: top_sim
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
`include "..\rtl\include.v"

`define MaxTestSamples 100

module top_sim(
    
    );
    
    reg reset;
    reg clock;
    reg [`dataWidth-1:0] in;
    reg in_valid;
    reg [`dataWidth-1:0] in_mem [1024:0];
//    reg [7:0] fileName[127:0];
    reg [7:0] fileName[29:0];
    reg s_axi_awvalid;
    reg [31:0] s_axi_awaddr;
    wire s_axi_awready;
    reg [31:0] s_axi_wdata;
    reg s_axi_wvalid;
    wire s_axi_wready;
    wire s_axi_bvalid;
    reg s_axi_bready;
    wire intr;
    reg [31:0] axiRdData;
    reg [31:0] s_axi_araddr;
    wire [31:0] s_axi_rdata;
    reg s_axi_arvalid;
    wire s_axi_arready;
    wire s_axi_rvalid;
    reg s_axi_rready;
    reg [`dataWidth-1:0] expected;

    wire [31:0] numNeurons[31:1];
    wire [31:0] numWeights[31:1];
    
    assign numNeurons[1] = 128;
    assign numNeurons[2] = 24;
    assign numNeurons[3] = 4;
    
//    assign numWeights[1] = 3056;
    assign numWeights[1] = 1024;
    assign numWeights[2] = 128;
    assign numWeights[3] = 24;
    
    integer right=0;
    integer wrong=0;
    
    zyNet dut(
    .s_axi_aclk(clock),
    .s_axi_aresetn(reset),
    .s_axi_awaddr(s_axi_awaddr),
    .s_axi_awprot(0),
    .s_axi_awvalid(s_axi_awvalid),
    .s_axi_awready(s_axi_awready),
    .s_axi_wdata(s_axi_wdata),
    .s_axi_wstrb(4'hF),
    .s_axi_wvalid(s_axi_wvalid),
    .s_axi_wready(s_axi_wready),
    .s_axi_bresp(),
    .s_axi_bvalid(s_axi_bvalid),
    .s_axi_bready(s_axi_bready),
    .s_axi_araddr(s_axi_araddr),
    .s_axi_arprot(0),
    .s_axi_arvalid(s_axi_arvalid),
    .s_axi_arready(s_axi_arready),
    .s_axi_rdata(s_axi_rdata),
    .s_axi_rresp(),
    .s_axi_rvalid(s_axi_rvalid),
    .s_axi_rready(s_axi_rready),
    .axis_in_data(in),
    .axis_in_data_valid(in_valid),
    .axis_in_data_ready(),
    .intr(intr)
    );
    
    
initial
    begin
        clock = 1'b0;
        s_axi_awvalid = 1'b0;
        s_axi_bready = 1'b0;
        s_axi_wvalid = 1'b0;
        s_axi_arvalid = 1'b0;
    end
        
    always
        #5 clock = ~clock;
    
    function [7:0] to_ascii;
      input integer a;
      begin
        to_ascii = a+48;
      end
    endfunction
    
    always @(posedge clock)
    begin
        s_axi_bready <= s_axi_bvalid;
        s_axi_rready <= s_axi_rvalid;
    end
    
    task writeAxi(
    input [31:0] address,
    input [31:0] data
    );
    begin
        @(posedge clock);
        s_axi_awvalid <= 1'b1;
        s_axi_awaddr <= address;
        s_axi_wdata <= data;
        s_axi_wvalid <= 1'b1;
        wait(s_axi_wready);
        @(posedge clock);
        s_axi_awvalid <= 1'b0;
        s_axi_wvalid <= 1'b0;
        @(posedge clock);
    end
    endtask
    
    task readAxi(
    input [31:0] address
    );
    begin
        @(posedge clock);
        s_axi_arvalid <= 1'b1;
        s_axi_araddr <= address;
        wait(s_axi_arready);
        @(posedge clock);
        s_axi_arvalid <= 1'b0;
        wait(s_axi_rvalid);
        @(posedge clock);
        axiRdData <= s_axi_rdata;
        @(posedge clock);
    end
    endtask

task configWeights();
    integer i,j,k,t;
    integer neuronNo_int;
    reg [80*9:0] fileName; // To handle concatenated strings      Change
    reg [`dataWidth:0] config_mem [1023:0];
    begin
        @(posedge clock);
        for(k=1;k<`numLayers;k=k+1)
        begin
            writeAxi(12,k);//Write layer number
            for(j=1;j<=numNeurons[k];j=j+1)
            begin
                neuronNo_int = j;
                fileName[0] = "f";
                fileName[1] = "i";
                fileName[2] = "m";
                fileName[3] = ".";
                fileName[4] = "b";
                fileName[5] = "_";
                if(j > 99)
                begin
                    fileName[6] = 48;  //LSB
                    fileName[7] = 48;
                    fileName[8] = 48; //MSB
                    i=0;
                    while(neuronNo_int != 0)
                    begin
                        fileName[i+4] = to_ascii(neuronNo_int%10);
                        neuronNo_int = neuronNo_int/10;
                        i=i+1;
                    end 
                    fileName[9] = "_";
                    fileName[10] = to_ascii(k);
                    fileName[11] = "_";
                    fileName[12] = "L";
                end
                
                if(j > 9)
                begin
                    fileName[6] = 48;  //LSB
                    fileName[7] = 48;
                    i=0;
                    while(neuronNo_int != 0)
                    begin
                        fileName[i+4] = to_ascii(neuronNo_int%10);
                        neuronNo_int = neuronNo_int/10;
                        i=i+1;
                    end 
                    fileName[8] = "_";
                    fileName[9] = to_ascii(k);
                    fileName[10] = "_";
                    fileName[11] = "L";
                end
                
                else
                begin
                    fileName[6] = 48;
                    i=0;
                    while(neuronNo_int != 0)
                    begin
                        fileName[i+4] = to_ascii(neuronNo_int%10);
                        neuronNo_int = neuronNo_int/10;
                        i=i+1;
                    end 
                    fileName[7] = "_";
                    fileName[8] = to_ascii(k);
                    fileName[9] = "_";
                    fileName[10] = "L";
                end
                $readmemb(fileName, config_mem);
                writeAxi(16,j);//Write neuron number
                for (t=0; t<numWeights[k]; t=t+1) begin
                    writeAxi(0,{15'd0,config_mem[t]});
                end 
            end
        end
    end
    endtask


    
//task configBias();
//    integer i,j,k,t;
//    integer neuronNo_int;
//    reg [31:0] bias[0:0];
//    reg [80*10:0] fileName; // To handle concatenated strings      Change
//    begin
//        @(posedge clock);
//        for(k=1;k<`numLayers;k=k+1)
//        begin
//            writeAxi(12,k);//Write layer number
//            for(j=0;j<numNeurons[k];j=j+1)
//            begin
//                neuronNo_int = j;
//                fileName[0] = "f";
//                fileName[1] = "i";
//                fileName[2] = "m";
//                fileName[3] = ".";
//                if(j>99)
//                begin
//                    fileName[4] = 48;
//                    fileName[5] = 48;
//                    fileName[6] = 48;
//                    i=0;
//                    while(neuronNo_int != 0)
//                    begin
//                        fileName[i+4] = to_ascii(neuronNo_int%10);
//                        neuronNo_int = neuronNo_int/10;
//                        i=i+1;
//                    end 
//                    fileName[7] = "_";
//                    fileName[8] = to_ascii(k);
//                    fileName[9] = "_";
//                    fileName[10] = "b";
//                end
                
//                else if(j>9)
//                begin
//                    fileName[4] = 48;
//                    fileName[5] = 48;
//                    i=0;
//                    while(neuronNo_int != 0)
//                    begin
//                        fileName[i+4] = to_ascii(neuronNo_int%10);
//                        neuronNo_int = neuronNo_int/10;
//                        i=i+1;
//                    end 
//                    fileName[6] = "_";
//                    fileName[7] = to_ascii(k);
//                    fileName[8] = "_";
//                    fileName[9] = "b";
//                end
                
//                else
//                begin
//                    fileName[4] = 48;
//                    i=0;
//                    while(neuronNo_int != 0)
//                    begin
//                        fileName[i+4] = to_ascii(neuronNo_int%10);
//                        neuronNo_int = neuronNo_int/10;
//                        i=i+1;
//                    end 
//                    fileName[5] = "_";
//                    fileName[6] = to_ascii(k);
//                    fileName[7] = "_";
//                    fileName[8] = "b";               
//                end
//                $readmemb(fileName, bias);
//                writeAxi(16,j);//Write neuron number
//                writeAxi(4,{15'd0,bias[0]});
//            end
//        end
//    end
//    endtask
    
    
// WORKING
//task configBias();
//    integer i, j, k, t;
//    integer neuronNo_int;
//    integer tempIndex;
//    reg [7:0] tempDigits[9:0]; // Temporary storage for digits
//    reg [31:0] bias[0:0];
//    reg [80*10:0] fileName; // To handle concatenated strings
//    begin
//        @(posedge clock);
//        for(k = 1; k < `numLayers; k = k + 1) begin
//            writeAxi(12, k); // Write layer number
//            for(j = 0; j < numNeurons[k]; j = j + 1) begin
//                neuronNo_int = j;
                
//                // Initialize filename prefix
//                fileName[0] = "f";
//                fileName[1] = "i";
//                fileName[2] = "m";
//                fileName[3] = ".";
                
//                // Convert neuron number to ASCII without leading zero padding
//                tempIndex = 0;
//                if (neuronNo_int == 0) begin
//                    tempDigits[tempIndex] = to_ascii(0);
//                    tempIndex = tempIndex + 1;
//                end
//                else begin
//                    while (neuronNo_int != 0) begin
//                        tempDigits[tempIndex] = to_ascii(neuronNo_int % 10);
//                        neuronNo_int = neuronNo_int / 10;
//                        tempIndex = tempIndex + 1;
//                    end
//                end
                
//                // Reverse the digits and store them in the filename
//                for (i = 0; i < tempIndex; i = i + 1) begin
//                    fileName[4 + i] = tempDigits[tempIndex - 1 - i];
//                end
                
//                // Add remaining fixed parts of the filename
//                fileName[4 + tempIndex] = "_";
//                fileName[5 + tempIndex] = to_ascii(k); // Layer number
//                fileName[6 + tempIndex] = "_";
//                fileName[7 + tempIndex] = "b";

//                $readmemb(fileName, bias);
//                writeAxi(16, j); // Write neuron number
//                writeAxi(4, {15'd0, bias[0]});
//            end
//        end
//    end
//endtask




task configBias();
    integer i, j, k, t;
    integer neuronNo_int;
    integer tempIndex;
    reg [7:0] tempDigits[9:0]; // Temporary storage for digits
    reg [31:0] bias[0:0];
    reg [80*10:0] fileName; // To handle concatenated strings
    begin
        @(posedge clock);
        for(k = 1; k < `numLayers; k = k + 1) begin
            writeAxi(12, k); // Write layer number
            for(j = 0; j < numNeurons[k]; j = j + 1) begin
                neuronNo_int = j;
                
                // Initialize filename prefix
                fileName[0] = "f";
                fileName[1] = "i";
                fileName[2] = "m";
                fileName[3] = ".";
                
                // Convert neuron number to ASCII without leading zero padding
                tempIndex = 0;
                if (neuronNo_int == 0) begin
                    tempDigits[tempIndex] = to_ascii(0);
                    tempIndex = tempIndex + 1;
                end
                else begin
                    while (neuronNo_int != 0) begin
                        tempDigits[tempIndex] = to_ascii(neuronNo_int % 10);
                        neuronNo_int = neuronNo_int / 10;
                        tempIndex = tempIndex + 1;
                    end
                end
                
                // Reverse the digits and store them in the filename
                for (i = 0; i < tempIndex; i = i + 1) begin
                    fileName[4 + i] = tempDigits[tempIndex - 1 - i];
                end
                
                // Add remaining fixed parts of the filename
                fileName[4 + tempIndex] = "_";
                fileName[5 + tempIndex] = to_ascii(k); // Layer number
                fileName[6 + tempIndex] = "_";
                fileName[7 + tempIndex] = "b";

                $readmemb(fileName, bias);
                
                // Display the bias value with its file name
                $display("Layer: %0d, Neuron: %0d, File: %0s, Bias: %0d", k, j, fileName, bias[0]);
                
                writeAxi(16, j); // Write neuron number
                writeAxi(4, {15'd0, bias[0]});
            end
        end
    end
endtask

    
    task sendData();
    //input [25*7:0] fileName;
    integer t;
    reg [80*8:0] fileName; // To handle concatenated strings      Change
    begin
//        $readmemb(fileName, in_mem);
        $readmemb("sample_1_b.mif", in_mem); 
        @(posedge clock);
        @(posedge clock);
        @(posedge clock);
        for (t=0; t <1023; t=t+1) begin
            @(posedge clock);
            in <= in_mem[t];
            in_valid <= 1;
            //@(posedge clock);
            //in_valid <= 0;
        end 
        @(posedge clock);
        in_valid <= 0;
        expected = in_mem[t];
    end
    endtask
   
    integer i,j,layerNo=1,k;
    integer start;
    integer testDataCount;
    integer testDataCount_int;
    initial
    begin
        reset = 0;
        in_valid = 0;
        #100;
        reset = 1;
        #100
        writeAxi(28,0);//clear soft reset
        start = $time;
        `ifndef pretrained
            configWeights();
            configBias();
        `endif
        $display("Configuration completed",,,,$time-start,,"ns");
        start = $time;
        for(testDataCount=0;testDataCount<`MaxTestSamples;testDataCount=testDataCount+1)
        begin
            testDataCount_int = testDataCount;
            fileName[0] = "t";
            fileName[1] = "x";
            fileName[2] = "t";
            fileName[3] = ".";
            fileName[4] = "0";
            fileName[5] = "0";
            fileName[6] = "0";
            fileName[7] = "0";
            i=0;
            while(testDataCount_int != 0)
            begin
                fileName[i+4] = to_ascii(testDataCount_int%10);
                testDataCount_int = testDataCount_int/10;
                i=i+1;
            end 
            fileName[8] = "_";
            fileName[9] = "a";
            fileName[10] = "t";
            fileName[11] = "a";
            fileName[12] = "d";
            fileName[13] = "_";
            fileName[14] = "t";
            fileName[15] = "s";
            fileName[16] = "e";
            fileName[17] = "t";
            sendData();
            @(posedge intr);
            //readAxi(24);
            //$display("Status: %0x",axiRdData);
            readAxi(8);
            if(axiRdData==expected)
                right = right+1;
            $display("%0d. Accuracy: %f, Detected number: %0x, Expected: %x",testDataCount+1,right*100.0/(testDataCount+1),axiRdData,expected);
            /*$display("Total execution time",,,,$time-start,,"ns");
            j=0;
            repeat(10)
            begin
                readAxi(20);
                $display("Output of Neuron %d: %0x",j,axiRdData);
                j=j+1;
            end*/
        end
        $display("Accuracy: %f",right*100.0/testDataCount);
        $stop;
    end

endmodule