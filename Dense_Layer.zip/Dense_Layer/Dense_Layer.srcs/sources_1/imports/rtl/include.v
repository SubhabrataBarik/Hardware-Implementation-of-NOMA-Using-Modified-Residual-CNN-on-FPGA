`define pretrained
`define numLayers 4
//`define numLayers 3
`define dataWidth 16

`define numNeuronLayer1 128
`define numWeightLayer1 3056
`define Layer1ActType "relu"

`define numNeuronLayer2 24
`define numWeightLayer2 128
`define Layer2ActType "relu"

`define numNeuronLayer3 4
`define numWeightLayer3 24
`define Layer3ActType "relu"

`define numNeuronLayer4 4
`define numWeightLayer4 4
`define Layer4ActType "hardmax"

`define sigmoidSize 5
`define weightIntWidth 4
