module Layer_1 #(parameter NN = 30,numWeight=784,dataWidth=16,layerNum=1,sigmoidSize=10,weightIntWidth=4,actType="relu")
    (
    input           clk,
    input           rst,
    input           weightValid,
    input           biasValid,
    input [31:0]    weightValue,
    input [31:0]    biasValue,
    input [31:0]    config_layer_num,
    input [31:0]    config_neuron_num,
    input           x_valid,
    input [dataWidth-1:0]    x_in,
    output [NN-1:0]     o_valid,
    output [NN*dataWidth-1:0]  x_out
    );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(0), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_1_b.mif"), .biasFile("b_1_0.mif")) n_0 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[0*dataWidth+:dataWidth]),
        .outvalid(o_valid[0])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(1), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_2_b.mif"), .biasFile("b_1_1.mif")) n_1 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[1*dataWidth+:dataWidth]),
        .outvalid(o_valid[1])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(2), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_3_b.mif"), .biasFile("b_1_2.mif")) n_2 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[2*dataWidth+:dataWidth]),
        .outvalid(o_valid[2])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(3), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_4_b.mif"), .biasFile("b_1_3.mif")) n_3 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[3*dataWidth+:dataWidth]),
        .outvalid(o_valid[3])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(4), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_5_b.mif"), .biasFile("b_1_4.mif")) n_4 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[4*dataWidth+:dataWidth]),
        .outvalid(o_valid[4])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(5), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_6_b.mif"), .biasFile("b_1_5.mif")) n_5 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[5*dataWidth+:dataWidth]),
        .outvalid(o_valid[5])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(6), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_7_b.mif"), .biasFile("b_1_6.mif")) n_6 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[6*dataWidth+:dataWidth]),
        .outvalid(o_valid[6])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(7), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_8_b.mif"), .biasFile("b_1_7.mif")) n_7 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[7*dataWidth+:dataWidth]),
        .outvalid(o_valid[7])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(8), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_9_b.mif"), .biasFile("b_1_8.mif")) n_8 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[8*dataWidth+:dataWidth]),
        .outvalid(o_valid[8])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(9), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_10_b.mif"), .biasFile("b_1_9.mif")) n_9 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[9*dataWidth+:dataWidth]),
        .outvalid(o_valid[9])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(10), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_11_b.mif"), .biasFile("b_1_10.mif")) n_10 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[10*dataWidth+:dataWidth]),
        .outvalid(o_valid[10])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(11), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_12_b.mif"), .biasFile("b_1_11.mif")) n_11 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[11*dataWidth+:dataWidth]),
        .outvalid(o_valid[11])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(12), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_13_b.mif"), .biasFile("b_1_12.mif")) n_12 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[12*dataWidth+:dataWidth]),
        .outvalid(o_valid[12])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(13), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_14_b.mif"), .biasFile("b_1_13.mif")) n_13 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[13*dataWidth+:dataWidth]),
        .outvalid(o_valid[13])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(14), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_15_b.mif"), .biasFile("b_1_14.mif")) n_14 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[14*dataWidth+:dataWidth]),
        .outvalid(o_valid[14])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(15), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_16_b.mif"), .biasFile("b_1_15.mif")) n_15 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[15*dataWidth+:dataWidth]),
        .outvalid(o_valid[15])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(16), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_17_b.mif"), .biasFile("b_1_16.mif")) n_16 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[16*dataWidth+:dataWidth]),
        .outvalid(o_valid[16])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(17), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_18_b.mif"), .biasFile("b_1_17.mif")) n_17 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[17*dataWidth+:dataWidth]),
        .outvalid(o_valid[17])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(18), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_19_b.mif"), .biasFile("b_1_18.mif")) n_18 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[18*dataWidth+:dataWidth]),
        .outvalid(o_valid[18])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(19), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_20_b.mif"), .biasFile("b_1_19.mif")) n_19 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[19*dataWidth+:dataWidth]),
        .outvalid(o_valid[19])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(20), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_21_b.mif"), .biasFile("b_1_20.mif")) n_20 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[20*dataWidth+:dataWidth]),
        .outvalid(o_valid[20])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(21), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_22_b.mif"), .biasFile("b_1_21.mif")) n_21 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[21*dataWidth+:dataWidth]),
        .outvalid(o_valid[21])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(22), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_23_b.mif"), .biasFile("b_1_22.mif")) n_22 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[22*dataWidth+:dataWidth]),
        .outvalid(o_valid[22])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(23), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_24_b.mif"), .biasFile("b_1_23.mif")) n_23 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[23*dataWidth+:dataWidth]),
        .outvalid(o_valid[23])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(24), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_25_b.mif"), .biasFile("b_1_24.mif")) n_24 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[24*dataWidth+:dataWidth]),
        .outvalid(o_valid[24])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(25), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_26_b.mif"), .biasFile("b_1_25.mif")) n_25 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[25*dataWidth+:dataWidth]),
        .outvalid(o_valid[25])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(26), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_27_b.mif"), .biasFile("b_1_26.mif")) n_26 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[26*dataWidth+:dataWidth]),
        .outvalid(o_valid[26])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(27), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_28_b.mif"), .biasFile("b_1_27.mif")) n_27 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[27*dataWidth+:dataWidth]),
        .outvalid(o_valid[27])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(28), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_29_b.mif"), .biasFile("b_1_28.mif")) n_28 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[28*dataWidth+:dataWidth]),
        .outvalid(o_valid[28])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(29), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_30_b.mif"), .biasFile("b_1_29.mif")) n_29 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[29*dataWidth+:dataWidth]),
        .outvalid(o_valid[29])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(30), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_31_b.mif"), .biasFile("b_1_30.mif")) n_30 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[30*dataWidth+:dataWidth]),
        .outvalid(o_valid[30])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(31), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_32_b.mif"), .biasFile("b_1_31.mif")) n_31 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[31*dataWidth+:dataWidth]),
        .outvalid(o_valid[31])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(32), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_33_b.mif"), .biasFile("b_1_32.mif")) n_32 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[32*dataWidth+:dataWidth]),
        .outvalid(o_valid[32])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(33), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_34_b.mif"), .biasFile("b_1_33.mif")) n_33 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[33*dataWidth+:dataWidth]),
        .outvalid(o_valid[33])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(34), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_35_b.mif"), .biasFile("b_1_34.mif")) n_34 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[34*dataWidth+:dataWidth]),
        .outvalid(o_valid[34])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(35), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_36_b.mif"), .biasFile("b_1_35.mif")) n_35 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[35*dataWidth+:dataWidth]),
        .outvalid(o_valid[35])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(36), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_37_b.mif"), .biasFile("b_1_36.mif")) n_36 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[36*dataWidth+:dataWidth]),
        .outvalid(o_valid[36])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(37), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_38_b.mif"), .biasFile("b_1_37.mif")) n_37 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[37*dataWidth+:dataWidth]),
        .outvalid(o_valid[37])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(38), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_39_b.mif"), .biasFile("b_1_38.mif")) n_38 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[38*dataWidth+:dataWidth]),
        .outvalid(o_valid[38])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(39), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_40_b.mif"), .biasFile("b_1_39.mif")) n_39 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[39*dataWidth+:dataWidth]),
        .outvalid(o_valid[39])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(40), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_41_b.mif"), .biasFile("b_1_40.mif")) n_40 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[40*dataWidth+:dataWidth]),
        .outvalid(o_valid[40])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(41), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_42_b.mif"), .biasFile("b_1_41.mif")) n_41 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[41*dataWidth+:dataWidth]),
        .outvalid(o_valid[41])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(42), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_43_b.mif"), .biasFile("b_1_42.mif")) n_42 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[42*dataWidth+:dataWidth]),
        .outvalid(o_valid[42])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(43), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_44_b.mif"), .biasFile("b_1_43.mif")) n_43 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[43*dataWidth+:dataWidth]),
        .outvalid(o_valid[43])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(44), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_45_b.mif"), .biasFile("b_1_44.mif")) n_44 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[44*dataWidth+:dataWidth]),
        .outvalid(o_valid[44])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(45), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_46_b.mif"), .biasFile("b_1_45.mif")) n_45 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[45*dataWidth+:dataWidth]),
        .outvalid(o_valid[45])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(46), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_47_b.mif"), .biasFile("b_1_46.mif")) n_46 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[46*dataWidth+:dataWidth]),
        .outvalid(o_valid[46])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(47), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_48_b.mif"), .biasFile("b_1_47.mif")) n_47 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[47*dataWidth+:dataWidth]),
        .outvalid(o_valid[47])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(48), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_49_b.mif"), .biasFile("b_1_48.mif")) n_48 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[48*dataWidth+:dataWidth]),
        .outvalid(o_valid[48])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(49), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_50_b.mif"), .biasFile("b_1_49.mif")) n_49 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[49*dataWidth+:dataWidth]),
        .outvalid(o_valid[49])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(50), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_51_b.mif"), .biasFile("b_1_50.mif")) n_50 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[50*dataWidth+:dataWidth]),
        .outvalid(o_valid[50])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(51), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_52_b.mif"), .biasFile("b_1_51.mif")) n_51 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[51*dataWidth+:dataWidth]),
        .outvalid(o_valid[51])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(52), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_53_b.mif"), .biasFile("b_1_52.mif")) n_52 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[52*dataWidth+:dataWidth]),
        .outvalid(o_valid[52])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(53), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_54_b.mif"), .biasFile("b_1_53.mif")) n_53 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[53*dataWidth+:dataWidth]),
        .outvalid(o_valid[53])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(54), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_55_b.mif"), .biasFile("b_1_54.mif")) n_54 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[54*dataWidth+:dataWidth]),
        .outvalid(o_valid[54])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(55), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_56_b.mif"), .biasFile("b_1_55.mif")) n_55 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[55*dataWidth+:dataWidth]),
        .outvalid(o_valid[55])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(56), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_57_b.mif"), .biasFile("b_1_56.mif")) n_56 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[56*dataWidth+:dataWidth]),
        .outvalid(o_valid[56])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(57), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_58_b.mif"), .biasFile("b_1_57.mif")) n_57 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[57*dataWidth+:dataWidth]),
        .outvalid(o_valid[57])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(58), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_59_b.mif"), .biasFile("b_1_58.mif")) n_58 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[58*dataWidth+:dataWidth]),
        .outvalid(o_valid[58])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(59), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_60_b.mif"), .biasFile("b_1_59.mif")) n_59 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[59*dataWidth+:dataWidth]),
        .outvalid(o_valid[59])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(60), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_61_b.mif"), .biasFile("b_1_60.mif")) n_60 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[60*dataWidth+:dataWidth]),
        .outvalid(o_valid[60])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(61), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_62_b.mif"), .biasFile("b_1_61.mif")) n_61 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[61*dataWidth+:dataWidth]),
        .outvalid(o_valid[61])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(62), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_63_b.mif"), .biasFile("b_1_62.mif")) n_62 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[62*dataWidth+:dataWidth]),
        .outvalid(o_valid[62])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(63), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_64_b.mif"), .biasFile("b_1_63.mif")) n_63 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[63*dataWidth+:dataWidth]),
        .outvalid(o_valid[63])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(64), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_65_b.mif"), .biasFile("b_1_64.mif")) n_64 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[64*dataWidth+:dataWidth]),
        .outvalid(o_valid[64])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(65), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_66_b.mif"), .biasFile("b_1_65.mif")) n_65 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[65*dataWidth+:dataWidth]),
        .outvalid(o_valid[65])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(66), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_67_b.mif"), .biasFile("b_1_66.mif")) n_66 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[66*dataWidth+:dataWidth]),
        .outvalid(o_valid[66])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(67), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_68_b.mif"), .biasFile("b_1_67.mif")) n_67 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[67*dataWidth+:dataWidth]),
        .outvalid(o_valid[67])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(68), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_69_b.mif"), .biasFile("b_1_68.mif")) n_68 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[68*dataWidth+:dataWidth]),
        .outvalid(o_valid[68])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(69), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_70_b.mif"), .biasFile("b_1_69.mif")) n_69 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[69*dataWidth+:dataWidth]),
        .outvalid(o_valid[69])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(70), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_71_b.mif"), .biasFile("b_1_70.mif")) n_70 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[70*dataWidth+:dataWidth]),
        .outvalid(o_valid[70])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(71), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_72_b.mif"), .biasFile("b_1_71.mif")) n_71 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[71*dataWidth+:dataWidth]),
        .outvalid(o_valid[71])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(72), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_73_b.mif"), .biasFile("b_1_72.mif")) n_72 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[72*dataWidth+:dataWidth]),
        .outvalid(o_valid[72])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(73), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_74_b.mif"), .biasFile("b_1_73.mif")) n_73 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[73*dataWidth+:dataWidth]),
        .outvalid(o_valid[73])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(74), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_75_b.mif"), .biasFile("b_1_74.mif")) n_74 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[74*dataWidth+:dataWidth]),
        .outvalid(o_valid[74])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(75), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_76_b.mif"), .biasFile("b_1_75.mif")) n_75 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[75*dataWidth+:dataWidth]),
        .outvalid(o_valid[75])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(76), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_77_b.mif"), .biasFile("b_1_76.mif")) n_76 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[76*dataWidth+:dataWidth]),
        .outvalid(o_valid[76])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(77), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_78_b.mif"), .biasFile("b_1_77.mif")) n_77 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[77*dataWidth+:dataWidth]),
        .outvalid(o_valid[77])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(78), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_79_b.mif"), .biasFile("b_1_78.mif")) n_78 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[78*dataWidth+:dataWidth]),
        .outvalid(o_valid[78])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(79), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_80_b.mif"), .biasFile("b_1_79.mif")) n_79 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[79*dataWidth+:dataWidth]),
        .outvalid(o_valid[79])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(80), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_81_b.mif"), .biasFile("b_1_80.mif")) n_80 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[80*dataWidth+:dataWidth]),
        .outvalid(o_valid[80])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(81), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_82_b.mif"), .biasFile("b_1_81.mif")) n_81 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[81*dataWidth+:dataWidth]),
        .outvalid(o_valid[81])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(82), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_83_b.mif"), .biasFile("b_1_82.mif")) n_82 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[82*dataWidth+:dataWidth]),
        .outvalid(o_valid[82])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(83), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_84_b.mif"), .biasFile("b_1_83.mif")) n_83 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[83*dataWidth+:dataWidth]),
        .outvalid(o_valid[83])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(84), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_85_b.mif"), .biasFile("b_1_84.mif")) n_84 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[84*dataWidth+:dataWidth]),
        .outvalid(o_valid[84])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(85), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_86_b.mif"), .biasFile("b_1_85.mif")) n_85 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[85*dataWidth+:dataWidth]),
        .outvalid(o_valid[85])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(86), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_87_b.mif"), .biasFile("b_1_86.mif")) n_86 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[86*dataWidth+:dataWidth]),
        .outvalid(o_valid[86])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(87), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_88_b.mif"), .biasFile("b_1_87.mif")) n_87 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[87*dataWidth+:dataWidth]),
        .outvalid(o_valid[87])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(88), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_89_b.mif"), .biasFile("b_1_88.mif")) n_88 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[88*dataWidth+:dataWidth]),
        .outvalid(o_valid[88])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(89), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_90_b.mif"), .biasFile("b_1_89.mif")) n_89 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[89*dataWidth+:dataWidth]),
        .outvalid(o_valid[89])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(90), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_91_b.mif"), .biasFile("b_1_90.mif")) n_90 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[90*dataWidth+:dataWidth]),
        .outvalid(o_valid[90])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(91), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_92_b.mif"), .biasFile("b_1_91.mif")) n_91 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[91*dataWidth+:dataWidth]),
        .outvalid(o_valid[91])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(92), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_93_b.mif"), .biasFile("b_1_92.mif")) n_92 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[92*dataWidth+:dataWidth]),
        .outvalid(o_valid[92])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(93), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_94_b.mif"), .biasFile("b_1_93.mif")) n_93 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[93*dataWidth+:dataWidth]),
        .outvalid(o_valid[93])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(94), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_95_b.mif"), .biasFile("b_1_94.mif")) n_94 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[94*dataWidth+:dataWidth]),
        .outvalid(o_valid[94])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(95), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_96_b.mif"), .biasFile("b_1_95.mif")) n_95 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[95*dataWidth+:dataWidth]),
        .outvalid(o_valid[95])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(96), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_97_b.mif"), .biasFile("b_1_96.mif")) n_96 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[96*dataWidth+:dataWidth]),
        .outvalid(o_valid[96])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(97), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_98_b.mif"), .biasFile("b_1_97.mif")) n_97 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[97*dataWidth+:dataWidth]),
        .outvalid(o_valid[97])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(98), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_99_b.mif"), .biasFile("b_1_98.mif")) n_98 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[98*dataWidth+:dataWidth]),
        .outvalid(o_valid[98])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(99), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_100_b.mif"), .biasFile("b_1_99.mif")) n_99 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[99*dataWidth+:dataWidth]),
        .outvalid(o_valid[99])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(100), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_101_b.mif"), .biasFile("b_1_100.mif")) n_100 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[100*dataWidth+:dataWidth]),
        .outvalid(o_valid[100])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(101), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_102_b.mif"), .biasFile("b_1_101.mif")) n_101 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[101*dataWidth+:dataWidth]),
        .outvalid(o_valid[101])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(102), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_103_b.mif"), .biasFile("b_1_102.mif")) n_102 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[102*dataWidth+:dataWidth]),
        .outvalid(o_valid[102])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(103), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_104_b.mif"), .biasFile("b_1_103.mif")) n_103 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[103*dataWidth+:dataWidth]),
        .outvalid(o_valid[103])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(104), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_105_b.mif"), .biasFile("b_1_104.mif")) n_104 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[104*dataWidth+:dataWidth]),
        .outvalid(o_valid[104])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(105), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_106_b.mif"), .biasFile("b_1_105.mif")) n_105 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[105*dataWidth+:dataWidth]),
        .outvalid(o_valid[105])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(106), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_107_b.mif"), .biasFile("b_1_106.mif")) n_106 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[106*dataWidth+:dataWidth]),
        .outvalid(o_valid[106])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(107), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_108_b.mif"), .biasFile("b_1_107.mif")) n_107 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[107*dataWidth+:dataWidth]),
        .outvalid(o_valid[107])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(108), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_109_b.mif"), .biasFile("b_1_108.mif")) n_108 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[108*dataWidth+:dataWidth]),
        .outvalid(o_valid[108])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(109), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_110_b.mif"), .biasFile("b_1_109.mif")) n_109 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[109*dataWidth+:dataWidth]),
        .outvalid(o_valid[109])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(110), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_111_b.mif"), .biasFile("b_1_110.mif")) n_110 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[110*dataWidth+:dataWidth]),
        .outvalid(o_valid[110])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(111), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_112_b.mif"), .biasFile("b_1_111.mif")) n_111 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[111*dataWidth+:dataWidth]),
        .outvalid(o_valid[111])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(112), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_113_b.mif"), .biasFile("b_1_112.mif")) n_112 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[112*dataWidth+:dataWidth]),
        .outvalid(o_valid[112])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(113), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_114_b.mif"), .biasFile("b_1_113.mif")) n_113 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[113*dataWidth+:dataWidth]),
        .outvalid(o_valid[113])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(114), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_115_b.mif"), .biasFile("b_1_114.mif")) n_114 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[114*dataWidth+:dataWidth]),
        .outvalid(o_valid[114])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(115), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_116_b.mif"), .biasFile("b_1_115.mif")) n_115 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[115*dataWidth+:dataWidth]),
        .outvalid(o_valid[115])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(116), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_117_b.mif"), .biasFile("b_1_116.mif")) n_116 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[116*dataWidth+:dataWidth]),
        .outvalid(o_valid[116])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(117), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_118_b.mif"), .biasFile("b_1_117.mif")) n_117 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[117*dataWidth+:dataWidth]),
        .outvalid(o_valid[117])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(118), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_119_b.mif"), .biasFile("b_1_118.mif")) n_118 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[118*dataWidth+:dataWidth]),
        .outvalid(o_valid[118])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(119), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_120_b.mif"), .biasFile("b_1_119.mif")) n_119 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[119*dataWidth+:dataWidth]),
        .outvalid(o_valid[119])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(120), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_121_b.mif"), .biasFile("b_1_120.mif")) n_120 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[120*dataWidth+:dataWidth]),
        .outvalid(o_valid[120])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(121), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_122_b.mif"), .biasFile("b_1_121.mif")) n_121 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[121*dataWidth+:dataWidth]),
        .outvalid(o_valid[121])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(122), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_123_b.mif"), .biasFile("b_1_122.mif")) n_122 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[122*dataWidth+:dataWidth]),
        .outvalid(o_valid[122])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(123), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_124_b.mif"), .biasFile("b_1_123.mif")) n_123 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[123*dataWidth+:dataWidth]),
        .outvalid(o_valid[123])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(124), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_125_b.mif"), .biasFile("b_1_124.mif")) n_124 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[124*dataWidth+:dataWidth]),
        .outvalid(o_valid[124])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(125), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_126_b.mif"), .biasFile("b_1_125.mif")) n_125 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[125*dataWidth+:dataWidth]),
        .outvalid(o_valid[125])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(126), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_127_b.mif"), .biasFile("b_1_126.mif")) n_126 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[126*dataWidth+:dataWidth]),
        .outvalid(o_valid[126])
        );

neuron #(.numWeight(numWeight), .layerNo(layerNum), .neuronNo(127), .dataWidth(dataWidth),
         .sigmoidSize(sigmoidSize), .weightIntWidth(weightIntWidth), .actType(actType),
         .weightFile("L_1_128_b.mif"), .biasFile("b_1_127.mif")) n_127 (
        .clk(clk),
        .rst(rst),
        .myinput(x_in),
        .weightValid(weightValid),
        .biasValid(biasValid),
        .weightValue(weightValue),
        .biasValue(biasValue),
        .config_layer_num(config_layer_num),
        .config_neuron_num(config_neuron_num),
        .myinputValid(x_valid),
        .out(x_out[127*dataWidth+:dataWidth]),
        .outvalid(o_valid[127])
        );

endmodule